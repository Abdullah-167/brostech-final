import React from "react";

export default function CompleteSection() {
  return (
    <div className="w-full lg:mt-20">
      {/* Counting Section */}
      <div className="w-full bg-white py-10">
        <div className="max-w-7xl mx-auto px-4">
          {/* Row Layout */}
          <div className="flex flex-wrap justify-center md:justify-between items-center text-center gap-6 md:gap-10">
            
            {/* Clutch Logo & Review */}
            <div className="flex flex-col items-center">
              <div className="flex items-center space-x-2">
                <p className="text-gray-700 text-lg font-medium">Reviewed on</p>
                <p className="text-gray-900 text-lg font-semibold">Clutch</p>
              </div>
              <p className="text-red-500 text-2xl">★★★★★</p>
            </div>

            {/* Separator */}
            <div className="hidden md:block w-px h-16 bg-gray-300"></div>

            {/* Years of Experience */}
            <div className="flex flex-col items-center">
              <p className="text-4xl md:text-5xl font-bold text-black">8</p>
              <p className="text-gray-700 text-lg font-medium">Years</p>
              <p className="text-gray-500">Proven Track Record</p>
            </div>

            {/* Separator */}
            <div className="hidden md:block w-px h-16 bg-gray-300"></div>

            {/* Customer Satisfaction */}
            <div className="flex flex-col items-center">
              <p className="text-4xl md:text-5xl font-bold text-black">100%</p>
              <p className="text-gray-700 text-lg font-medium">Customer Satisfaction</p>
            </div>

            {/* Separator */}
            <div className="hidden md:block w-px h-16 bg-gray-300"></div>

            {/* Completed Projects */}
            <div className="flex flex-col items-center">
              <p className="text-4xl md:text-5xl font-bold text-black">2,000</p>
              <p className="text-gray-700 text-lg font-medium">Projects</p>
              <p className="text-gray-500">We Have Completed</p>
            </div>

            {/* Separator */}
            <div className="hidden md:block w-px h-16 bg-gray-300"></div>

            {/* Average Answer Time */}
            <div className="flex flex-col items-center">
              <p className="text-4xl md:text-5xl font-bold text-black">3</p>
              <p className="text-gray-700 text-lg font-medium">Mins</p>
              <p className="text-gray-500">Average Answer Time</p>
            </div>

          </div>
        </div>
      </div>

      {/* Black Background Section */}
      <div className="w-full bg-black py-16 px-6 lg:mt-20">
        <div className="max-w-7xl lg:mx-20 text-white relative">
          {/* Content */}
          <div className="max-w-3xl">
            <button className="bg-lime-500 text-black font-semibold px-4 py-1 rounded">
              WHAT WE DO
            </button>
            <h2 className="text-4xl font-bold lg:mt-20 md:mt-10">
              Simplifying IT <br /> for a complex world.
            </h2>
          </div>

          {/* Pattern Design (Right Side) */}
          <div className="absolute bottom-4 right-4">
  <div className="flex flex-col gap-1">
    {Array.from({ length: 6 }).map((_, row) => (
      <div key={row} className="flex gap-1 justify-center">
        {Array.from({ length: row + 1 }).map((_, col) => (
          <div
            key={col}
            className="w-4 h-4 bg-yellow-500 rounded-sm"
          ></div>
        ))}
      </div>
    ))}
  </div>
</div>


        </div>
      </div>
    </div>
  );
}
