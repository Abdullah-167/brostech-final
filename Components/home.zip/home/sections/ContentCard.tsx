import React from "react";

export default function ContentCard() {
  return (
    <div className="flex flex-col lg:flex-row gap-10 items-center justify-center min-h-screen p-5">
      
      {/* Left Column (First & Third Box) */}
      <div className="flex flex-col gap-10">
        {/* First Box */}
        <div className="w-[520px] h-[70vh] bg-black text-white rounded-3xl shadow-lg p-8">
          <h1 className="text-5xl font-bold">Organizations</h1>
          <h1 className="text-5xl font-bold">recognized Fillinx</h1>
          <h1 className="text-5xl font-bold">Solutions work</h1>

          <div className="flex flex-wrap gap-6 mt-10">
            <div>
              <h1 className="text-3xl font-bold">Forbes</h1>
              <p className="text-sm">Forbes Member</p>
              <p className="text-sm">Council 2022</p>
            </div>

            <div>
              <h1 className="text-3xl font-bold">Google</h1>
              <p className="text-sm">Developers Certified</p>
              <p className="text-sm">Agency</p>
            </div>

            <div>
              <h1 className="text-3xl font-bold">Clutch</h1>
              <p className="text-sm">Top App Development</p>
              <p className="text-sm">Company in USA 2023</p>
            </div>
          </div>
        </div>

        {/* Third Box */}
        <div className="w-[520px] h-[70vh] bg-gradient-to-r from-yellow-500 to-green-600 text-black rounded-3xl shadow-lg p-12">
         
          <h1 className="text-5xl font-bold">We use latest</h1>
          <p className="text-5xl font-bold"> technologies to run</p>
            <h2 className="text-5xl font-bold">your project</h2>
            <p className="text-5xl font-bold"> smoothly</p>
               <div className="  space-x-2 mt-5">
                   <button className="bg-black p-3 text-white rounded-3xl">WordPress</button>
                   <button className="bg-black p-3 text-white rounded-3xl">Shopify</button>
                   <button className="bg-black p-3 text-white rounded-3xl" >Shopify Plus</button>
                   <button className="bg-black p-3 text-white rounded-3xl"> Angular js</button>
               </div>
               <div className="space-x-2 mt-3">
                    <button className="bg-black p-3 text-white rounded-3xl">React</button>
                   <button className="bg-black p-3 text-white rounded-3xl">Laravel</button>
                   <button className="bg-black p-3 text-white rounded-3xl">Vue Js Plus</button>
                   <button className="bg-black p-3 text-white rounded-3xl" >Flutter</button>
                   <button className="bg-black p-3 text-white rounded-3xl">Next Js</button>
               </div>
        </div>
      </div>

      {/* Right Column (Second & Fourth Box with Margin on Top) */}
      <div className="flex flex-col gap-10 lg:mt-40">
        {/* Second Box */}
        <div className="w-[520px] h-[70vh] bg-blue-700 text-white rounded-3xl shadow-lg p-8">
          <h1 className="text-5xl font-bold">Fillinx Solutions has</h1>
          <h1 className="text-5xl font-bold">been recognized as</h1>
          <h1 className="text-5xl font-bold">a Leader in the</h1>
          <h1 className="text-5xl font-bold">2022 Gartner®</h1>
        </div>

        {/* Fourth Box */}
        <div className="w-[520px] h-[70vh] bg-black text-white rounded-3xl shadow-lg p-14">
        
          <h1 className="text-5xl font-bold"> Create a great</h1>
          <p className="text-5xl font-bold"> career and grow</p>
          
            <h2 className="text-5xl font-bold">your future with</h2>
            <p className="text-5xl font-bold"> Fillinx Solutions</p>

            <button className="text-blue-600 hover:bg-blue-700 bg-white m-20 rounded-xl p-5">View Open Position</button>
        </div>
      </div>

    </div>
  );
}
