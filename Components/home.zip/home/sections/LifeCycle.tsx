import Image from "next/image";

export default function LifeCycle() {
    return (
        <div>
               <div className="text-heading  px-20">
                  <h1 className="text-4xl lg:w-1/2  font-bold">Discover Our Seamless Process for Websites, SEO, and Digital Marketing</h1>
               </div>
           
      <div className="flex  gap-2 py-10  lg:mx-20">
        <div className="px-4 py-2 rounded">
            <h1 className="text-5xl text-blue-600 font-extrabold text-center">1</h1> 
            <h3 className="text-xl text-black font-bold">Initiating a kick-off meeting</h3>
            <h3>kick smart project with concise</h3>
            <h3>informative kick-off meeting</h3>
            </div>

        <div className="text-3xl font-bold text-blue-600  py-20 rounded">
        <Image src="/yellow_arrow.jpg" alt="Sample" width={100} height={90} className="rounded" />
            </div>

        <div className="   py-24 rounded">
        <h1 className="text-5xl text-blue-600 font-extrabold text-center">2</h1> 
            <h3 className="text-xl text-black font-bold">Initiating a kick-off meeting</h3>
            <h3>kick smart project with concise</h3>
            <h3>informative kick-off meeting</h3>
        </div>

        <div className="text-3xl font-bold text-blue-600  py-40 rounded">
        <Image src="/yellow_arrow.jpg" alt="Sample" width={100} height={90} className="rounded" />
            </div>

            <div className="   py-48 rounded">
        <h1 className="text-5xl text-blue-600 font-extrabold text-center">3</h1> 
            <h3 className="text-xl text-black font-bold">Initiating a kick-off meeting</h3>
            <h3>kick smart project with concise</h3>
            <h3>informative kick-off meeting</h3>
        </div>

        <div className="text-3xl font-bold text-blue-600  py-64 rounded">
        <Image src="/yellow_arrow.jpg" alt="Sample" width={100} height={90} className="rounded" />
            </div>

       
           
        <div className="   pt-72 rounded">
        <h1 className="text-5xl text-blue-600 font-extrabold text-center">4</h1> 
            <h3 className="text-xl text-black font-bold">Initiating a kick-off meeting</h3>
            <h3>kick smart project with concise</h3>
            <h3>informative kick-off meeting</h3>
        </div>
      </div>
      </div>
    );
  }
  
