import React from "react";

export default function ContactForm() {
  return (
    <div className="bg-[#E6E6FA] rounded-3xl p-10 flex flex-col md:flex-row items-center justify-between w-full max-w-6xl mx-auto shadow-lg">
      {/* Left Section */}
      <div className="flex-1 text-left">
        <h2 className="text-4xl font-bold text-black mb-4">
          Got a project? <br /> Let’s talk →
        </h2>
        <p className="text-lg text-gray-700 mb-4">sales@fillinxsolutions.com</p>
        {/* Social Icons */}
        <div className="flex gap-4 text-xl">
          <i className="fa-brands fa-instagram"></i>
          <i className="fa-brands fa-dribbble"></i>
          <i className="fa-brands fa-linkedin"></i>
          <i className="fa-brands fa-facebook"></i>
          <i className="fa-brands fa-behance"></i>
        </div>
      </div>

      {/* Right Section - Form */}
      <div className="flex-1 w-full max-w-xl">
        <div className="grid grid-cols-2 gap-4 mb-4">
          <input type="text" placeholder="Your name" className="input-box" />
          <input type="email" placeholder="Email address" className="input-box" />
          <input type="tel" placeholder="Phone number" className="input-box" />
          <select className="input-box">
            <option value="">What is your budget?</option>
            <option value="<$1000">Less than $1000</option>
            <option value="$1000-$5000">$1000 - $5000</option>
            <option value="$5000+">More than $5000</option>
          </select>
          <input type="text" placeholder="Industry" className="input-box" />
          <input type="text" placeholder="How did you hear about us?" className="input-box" />
        </div>
        <textarea placeholder="Your project details..." className="input-box h-28 w-full"></textarea>

        <div className="flex items-center mt-4">
          <input type="checkbox" id="nda" className="mr-2" />
          <label htmlFor="nda" className="text-gray-700">I want an NDA to protect my idea</label>
        </div>

        <button className="mt-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg w-full">
          Schedule Free Consultation
        </button>
      </div>
    </div>
  );
}
