import React from "react";
import Image from "next/image";
import Link from "next/link";

export default function HomeSection() {
  return (
    <div className="home-section grid grid-cols-1 md:grid-cols-2 items-center w-full px-6 md:px-12 ">
      {/* Left Section - Text */}
      <div className="left w-full text-center md:text-left">
        <h1 className=" lg:text-6xl md:text-5xl font-bold ">
          We manage your IT, so you can manage your business.
        </h1>
        <h3 className="lg:text-5xl md:text-3xl mt-3">
          Leading Software & Mobile Development Agency
        </h3>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row justify-center md:justify-start gap-4 mt-5">
          <button className="bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-white hover:text-blue-600 transition duration-300 py-3 px-6">
            Schedule a Free Consultation
          </button>
          <button className="bg-white border border-blue-500 text-blue-500 font-semibold rounded-lg shadow-md hover:bg-blue-500 hover:text-white transition duration-300 py-3 px-6">
            Services
          </button>
        </div>
      </div>

      {/* Right Section - Responsive Image */}
      <div className="right w-full flex justify-center md:justify-end sm:mt-5">
        <Link href="/your-target">
          <Image
            src="/home-image.webp" // Replace with your image path
            alt="Description of the image"
            width={600} // Default width for large screens
            height={400} // Default height for large screens
            className="rounded-lg shadow-md w-full md:w-auto"
            style={{
              clipPath: "polygon(35% 0, 100% 0, 100% 55%, 100% 100%, 0 100%, 1% 67%, 33% 38%)",
            }}
            priority // Optimizes image loading
          />
        </Link>
      </div>
    </div>
  );
}
