import React from "react";
import { FaWordpress, FaNodeJs, FaReact, FaShopify } from "react-icons/fa";
import { SiWebflow, SiFlutter, SiLaravel } from "react-icons/si";
import { TbBrandSpotify } from "react-icons/tb";

export default function Technologies() {
  return (
    <div className="flex flex-col lg:flex-row items-center justify-between px-10 py-20 mx-36">
      {/* Left Side - Text Section */}
      <div className="lg:w-1/2 space-y-6">
        <span className="bg-gray-200 text-black px-4 py-1 text-sm rounded-md">PLATFORMS</span>
        <h1 className="text-5xl font-bold">Our Technologies and Platforms</h1>
        <p className="text-lg text-gray-600">
          Our expertise spans across various web development platforms, ensuring versatile solutions
          tailored to your unique needs and goals.
        </p>
        <button className="bg-blue-700 text-white px-6 py-3 rounded-md font-semibold text-lg hover:bg-blue-800">
          View All Technologies
        </button>
      </div>
      <div className="flex flex-col items-center justify-center py-10">
      <div className="flex gap-20 mb-6">
        <FaWordpress className="text-blue-500 text-6xl" />
        <SiWebflow className="text-indigo-600 text-6xl" />
      </div>
      <div className="flex items-center gap-20 mb-6">
        <FaShopify className="text-green-600 text-6xl" />
        <h2 className="text-4xl font-bold">
          <span className="italic text-black">shopify</span>
          <span className="text-yellow-500">plus</span>
        </h2>
        <SiLaravel className="text-red-500 text-6xl" />
      </div>
      <div className="flex gap-20">
        <SiFlutter className="text-blue-400 text-6xl" />
        <FaNodeJs className="text-green-500 text-6xl" />
        <FaReact className="text-blue-300 text-6xl" />
      </div>
    </div>
    </div>
  );
}
