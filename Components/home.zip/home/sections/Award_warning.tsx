"use client";
import { useState } from "react";

const servicesData = {
  custom: [
    {
      title: "Laravel",
      description:
        "We specialize in Laravel web development, crafting dynamic, efficient, and user-friendly websites for various purposes.",
      icon: "https://cdn.worldvectorlogo.com/logos/laravel-2.svg",
    },
    {
      title: "React",
      description:
        "We are skilled React developers crafting responsive, dynamic websites with modern UI/UX design and seamless functionality.",
      icon: "https://cdn.worldvectorlogo.com/logos/react-2.svg",
    },
    {
      title: "Node JS",
      description:
        "We create dynamic websites using Node.js, ensuring performance, scalability, and modern web development standards.",
      icon: "https://cdn.worldvectorlogo.com/logos/nodejs-icon.svg",
    },
  ],
  cms: [
    {
      title: "WordPress",
      description:
        "We build customized WordPress websites that are SEO-friendly and easy to manage.",
      icon: "https://cdn.worldvectorlogo.com/logos/wordpress-blue.svg",
    },
    {
      title: "Shopify",
      description:
        "Our Shopify development services help businesses build high-converting e-commerce stores.",
      icon: "https://cdn.worldvectorlogo.com/logos/shopify.svg",
    },
    {
      title: "Drupal",
      description:
        "We offer enterprise-level Drupal solutions for robust content management.",
      icon: "https://cdn.worldvectorlogo.com/logos/drupal.svg",
    },
  ],
  mobileApps: [
    {
      title: "React Native",
      description:
        "We develop high-performance cross-platform mobile apps using React Native.",
      icon: "https://cdn.worldvectorlogo.com/logos/react-2.svg",
    },
    {
      title: "Flutter",
      description:
        "Our Flutter development services ensure beautiful UI and smooth performance for mobile apps.",
      icon: "https://cdn.worldvectorlogo.com/logos/flutter.svg",
    },
    {
      title: "Swift",
      description:
        "We build fast and scalable iOS apps using Apple's Swift programming language.",
      icon: "https://cdn.worldvectorlogo.com/logos/swift-15.svg",
    },
  ],
  marketing: [
    {
      title: "SEO Optimization",
      description:
        "Our SEO experts help businesses improve search engine rankings and drive organic traffic.",
      icon: "https://cdn.worldvectorlogo.com/logos/seo.svg",
    },
    {
      title: "Social Media Marketing",
      description:
        "We create engaging social media campaigns to boost brand visibility and user engagement.",
      icon: "https://cdn.worldvectorlogo.com/logos/social-media.svg",
    },
    {
      title: "Email Marketing",
      description:
        "Our email marketing strategies ensure high conversion rates and customer retention.",
      icon: "https://cdn.worldvectorlogo.com/logos/email.svg",
    },
  ],
};

export default function AwardWinning() {
  const [selectedCategory, setSelectedCategory] = useState("custom");

  return (
    <div className="bg-gradient-to-r from-green-100   to-blue-100 py-16">
      {/* Header Section (Title Left, Buttons Right) */}
      <div className="max-w-5xl mx-auto flex flex-col md:flex-row justify-between items-center mb-8">
        <h2 className="lg:text-4xl md:text-3xl font-bold text-black text-left">
          We provide clients with <br />
          <span className="text-black">Award-Winning services</span>
        </h2>

        {/* Navigation Buttons */}
        <div className="flex flex-wrap gap-4 mt-4 md:mt-0 text-end">
          {["custom", "cms", "mobileApps", "marketing"].map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-5 py-2 text-sm font-semibold rounded-full transition-all ${
                selectedCategory === category
                  ? "bg-blue-600 text-white"
                  : "bg-white text-black border"
              }`}
            >
              {category.charAt(0).toUpperCase() + category.slice(1).replace(/Apps/, " Apps")}
            </button>
          ))}
        </div>
      </div>

      {/* Services Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl   mx-auto lg:mt-20">
        {servicesData[selectedCategory].map((service, index) => (
          <div key={index} className="p-6 bg-white rounded-lg shadow-lg text-center">
            <img
              src={service.icon}
              alt={service.title}
              className="w-12 h-12 mx-auto mb-4"
            />
            <h3 className="text-lg font-semibold text-black">{service.title}</h3>
            <p className="text-gray-600 mt-2">{service.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
