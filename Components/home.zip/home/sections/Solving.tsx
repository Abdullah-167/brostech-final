export default function Solving() {
    const industries = [
      { name: "Health & Fitness", image: "/images/health-fitness.jpg" },
      { name: "Beauty & Cosmetics", image: "/images/beauty-cosmetics.jpg" },
      { name: "Fashion", image: "/images/fashion.jpg" },
      { name: "Food & Drinks", image: "/images/food-drinks.jpg" },
      { name: "Consulting Providers", image: "/images/consulting.jpg" },
      { name: "Non-Profit", image: "/images/nonprofit.jpg" },
    ];
  
    return (
        <div  className="flex flex-col items-center text-center py-16 px-4">
            <div className=" py-1 bg-gray-200 text-gray-700 self-start lg:ml-96 md:ml-28 text-xs font-semibold ">
          HOW WE DO
        </div>
      <div className="flex flex-col items-center text-center py-16 p-4 mb-5">
        <h1 className="text-5xl font-bold text-black mb-5">
          Solving IT challenges in every <br className="hidden md:inline" /> industry, every day.
        </h1>
  
        {/* Industry Categories */}
        <div className="flex flex-wrap justify-center gap-4 mt-6 w-1/2">
          {industries.map((industry, index) => (
            <div key={index} className="flex items-center gap-2 bg-gray-200 px-4 py-2 rounded-full cursor-pointer hover:bg-gray-300 transition">
              <img src={industry.image} alt={industry.name} className="w-8 h-8 rounded-full object-cover" />
              <span className="text-sm font-semibold">{industry.name}</span>
            </div>
          ))}
        </div>
  
        {/* View All Industries */}
        <a href="#" className="text-blue-600 text-sm font-semibold mt-6 hover:underline self-start lg:ml-56 md:ml-28">
          View All Industries
        </a>
      </div>
      </div>
    );
  }
  