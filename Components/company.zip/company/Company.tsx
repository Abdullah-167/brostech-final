import React from 'react'
import Heero from './section/Heero'
import Team from './section/Team'
import Mission from './section/Mission'
import CardData from './section/CardData'
import Team_Experience from './section/Team_Experience'
import Better_together from './section/Better_together'
import Technologies from './section/Technologies'
import CompanyFooter from './section/CompanyFooter'

export default function Company() {
  return (
    <>
      <Heero/>
      <Team/>
      <Mission/>
      <CardData/>
      <Team_Experience/>
      <Better_together/>
      <Technologies/>
      <CompanyFooter/>
    </>
  )
}
